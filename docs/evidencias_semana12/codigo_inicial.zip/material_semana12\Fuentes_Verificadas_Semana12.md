# Informe de fuentes verificadas — "Gestión de Estado Avanzada con Riverpod" en Flutter

### Temáticas 2.3.1 a 2.3.3 del sílabo SIS048 (Semana 12)

**Fecha de consulta de todas las fuentes: 15 de octubre de 2026.**
Metodología: cada dato se tomó de una página efectivamente recuperada con `web_fetch`
o de la API pública de `pub.dev` (`https://pub.dev/api/packages/<paquete>`), que
devuelve el JSON de metadatos de cada versión publicada. Cuando algo no pudo
verificarse, se dice explícitamente con la etiqueta **NO VERIFICADO**. No se
inventó ningún dato, ninguna cita y ninguna fecha.

> Los tres informes crudos de la investigación están en esta misma carpeta:
> `informe_riverpod_verificado.md`, `informe_riverpod_docs.md` y
> `informe_riverpod_family_codegen_containers.md`. Este documento es la
> destilación verificable de ellos, más las comprobaciones hechas **contra el
> propio entorno de laboratorio** (Dart 3.12.2 / Flutter 3.44.9).

---

## ⚠️ 0. CORRECCIONES PREVIAS (la premisa habitual está desactualizada)

Antes de los puntos numerados, cinco correcciones verificadas, porque cambian
el contenido del material:

| Suposición frecuente | Realidad verificada | Fuente |
|---|---|---|
| Riverpod va por la versión 2.x | **Riverpod 3.0.0 salió el 2025-09-10** y la última estable es **3.4.3 (2026-09-03)** | pub.dev/changelog · API de pub.dev |
| `riverpod_annotation` comparte número con `riverpod` | **No.** `riverpod` está en 3.4.3 y `riverpod_annotation` en **4.0.7**; `riverpod_generator` en 4.0.9 | API de pub.dev |
| El lint de Riverpod se activa con `custom_lint` | **Ya no.** Desde 3.1.6, `riverpod_lint` se implementa con `analysis_server_plugin`: se declara en `analysis_options.yaml` y lo ejecuta `dart analyze` | pub.dev/packages/riverpod_lint · docs |
| `ProviderContainer` en pruebas se cierra con `addTearDown(container.dispose)` | **El reemplazo oficial es `ProviderContainer.test()`**, que "automatically disposes the container when the test ends" | https://riverpod.dev/docs/how_to/testing |
| `StateProvider` y `StateNotifierProvider` siguen siendo la API principal | **Son "legacy"**: se movieron a `flutter_riverpod/legacy.dart` y el proyecto no los usa | https://riverpod.dev/docs/3.0_migration |

---

## 1. Versiones, fechas y SDK mínimo (verificado en la API de pub.dev)

Comando reproducible:

```bash
curl -s https://pub.dev/api/packages/flutter_riverpod | python3 -m json.tool | head -40
```

| Paquete | Última versión | `published` (ISO 8601) | SDK declarado | Publicador |
|---|---|---|---|---|
| `flutter_riverpod` | **3.4.3** | 2026-09-03T22:15:17Z | `sdk: ^3.12.0`, `flutter: >=3.0.0` | dash-overflow.net |
| `riverpod` | **3.4.3** | 2026-09-03T22:14:57Z | `sdk: ^3.12.0` | dash-overflow.net |
| `riverpod_annotation` | **4.0.7** | 2026-09-03T22:15:02Z | `sdk: ^3.12.0` | dash-overflow.net |
| `riverpod_generator` | **4.0.9** | 2026-09-03T22:15:10Z | `sdk: ^3.12.0` | dash-overflow.net |
| `hooks_riverpod` | **3.4.3** | 2026-09-03T22:15:28Z | `sdk: ^3.12.0` | dash-overflow.net |
| `riverpod_lint` | **3.1.9** | 2026-09-03T22:15:23Z | **`>=3.13.0-0 <4.0.0`** | *unverified uploader* |
| `custom_lint` | 0.8.1 | 2025-09-09T14:08:31Z | `>=3.0.0 <4.0.0` | invertate.io |
| `build_runner` | 2.17.1 | 2026-10-14T13:08:54Z | `sdk: ^3.11.0` | tools.dart.dev |

**URLs consultadas:** `https://pub.dev/api/packages/<paquete>` ·
https://pub.dev/packages/flutter_riverpod · https://pub.dev/packages/riverpod/changelog

### 1.1. Hitos de la línea 3.x (changelog oficial)

| Versión | Fecha | Nota |
|---|---|---|
| 3.0.0 | **2025-09-10** | Primera estable de la versión 3 |
| 3.0.1 / 3.0.2 / 3.0.3 | 2025-09-30 / 2025-10-07 / 2025-10-09 | Correcciones |
| 3.1.0 | 2025-12-26 | `"Added an alternative way to combine asynchronous providers. This can be done by using AsyncValue.requireValue inside FutureProvider/AsyncNotifier"` |
| 3.2.0 / 3.2.1 | 2026-01-17 / 2026-02-03 | `"Added Ref.isPaused to check if there are any active/non-paused listeners."` |
| 3.3.2 | 2026-06-10 | Correcciones |
| 3.4.0 / 3.4.1 / 3.4.2 | 2026-07-26 / 2026-07-26 / 2026-07-28 | `"Added CustomProviderListenable"` |
| **3.4.3** | 2026-09-03 | `"- Upgraded analyzer to <15.0.0"` |

No existen las versiones 3.3.0 ni 3.3.1 (solo `3.3.2-dev.1` y `3.3.2-dev.2`).

### 1.2. Números de adopción de `flutter_riverpod`

`likeCount: 2913` · 140 puntos de pub · ~3,66 millones de descargas en 30 días ·
licencia **MIT** · repositorio https://github.com/rrousselGit/riverpod ·
plataformas declaradas: Android, iOS, Linux, macOS y Windows (**web no figura**
en la lista de plataformas, aunque el paquete `riverpod` sí lo declara).
Fuente: `https://pub.dev/api/packages/flutter_riverpod/score` y la página del paquete.

### 1.3. Comprobación en el entorno del laboratorio (no es una cita: es una medición)

| Dato | Valor medido el 2026-10-15 |
|---|---|
| `flutter --version` | Flutter **3.44.9** (stable, revision 6b182d2c75, 2026-08-05) |
| `dart --version` | Dart SDK **3.12.2** (stable) |
| Versiones resueltas por `flutter pub get` | `flutter_riverpod 3.4.3` · `riverpod 3.4.3` · `riverpod_annotation 4.0.7` · `riverpod_generator 4.0.9` · `build_runner 2.15.1` · `analyzer 13.0.0` · `drift_dev 2.35.1` · `state_notifier 1.0.0` |
| `riverpod_lint` | **No instalable**: 3.1.9 exige Dart `>=3.13.0-0`; 3.1.8 fija `riverpod 3.4.2`, incompatible con `flutter_riverpod 3.4.3` |
| `custom_lint` | **No necesario** con `riverpod_lint >= 3.1.6` |
| `state_notifier` | Sigue siendo dependencia transitiva de `flutter_riverpod` 3.4.3 (`">=0.7.2 <2.0.0"`) |

Reproducible con:
```bash
cd semana-12/manos_seguras_semana12 && flutter pub deps --style=compact | grep riverpod
```

---

## 2. Instalación para usar **generación de código** (bloque oficial)

Fuente: https://riverpod.dev/docs/introduction/getting_started (y su fuente
cruda `.../getting_started/pubspec.tsx`).

```yaml
dependencies:
  flutter_riverpod: ^<flutterRiverpodVersion>
  riverpod_annotation: ^<riverpodAnnotationVersion>

dev_dependencies:
  build_runner:
  riverpod_generator: ^<riverpodGeneratorVersion>
```

Citas textuales:

- `"If using code-generation, you can now run the code-generator with: dart run build_runner watch -d"`
- `"Riverpod_lint is implemented using analysis_server_plugin. As such, it is installed through analysis_options.yaml"`

**Dato importante:** el bloque oficial de `dev_dependencies` **solo** lleva
`build_runner` y `riverpod_generator`. `riverpod_annotation` va en
`dependencies`. `custom_lint` **no aparece** en la documentación de instalación
de Riverpod 3.

---

## 3. ¿Por qué Riverpod? (temática 2.3.1) — citas textuales oficiales

Fuente principal: https://riverpod.dev/docs/from_provider/motivation

- `"Riverpod is indeed a more modern, recommended and reliable approach when compared to Provider"`
- `"Declaring two Provider<Item> will result into unreliable behavior: InheritedWidget's API will obtain only one of the two... Riverpod simply doesn't have this problem."`
- `"With Provider, it's common to end-up with a ProviderNotFoundException... Although it brings much more utility than this, Riverpod simply can't throw this exception."`
- `"With Riverpod, providers are ready to use inside tests, by default."`
- `"Riverpod offers better State Management capabilities, better Caching strategies and a simplified Reactivity model."`

Fuente: https://riverpod.dev/docs/from_provider/provider_vs_riverpod

- `"With Riverpod, providers are not widgets. Instead they are plain Dart objects."`
- `"providers are defined outside of the widget tree, and instead are declared as global final variables."`
- `"it is possible to use Riverpod without Flutter."`
- `"Riverpod does not rely on generic types."`
- `"The rules for context.watch vs context.read applies to Riverpod too: Inside the build method, use \"watch\". Inside click handlers and other events, use \"read\"."`

Fuente: https://riverpod.dev/docs/root/faq

- `"relying on WidgetRef is equivalent to relying on BuildContext. It is effectively putting your logic in the UI layer, which is not recommended."`
- `"This is due to an unfortunate limitation in the API of InheritedWidget."`

### 3.1. Lo que **NO** se puede afirmar

- **NO VERIFICADO:** la documentación oficial de Riverpod **no menciona `setState`**
  en `root/faq`, `root/do_dont` ni en las páginas de motivación. La única guía
  sobre estado local es la regla de estado efímero (punto 10). Por tanto, la
  comparación «setState vs Riverpod» del material del curso es **elaboración
  propia del docente**, no una cita de la documentación.
- **NO VERIFICADO:** la expresión «compile-safe» / «compilación segura» **no
  aparece** en las páginas consultadas. Se usa en el material del curso solo
  como descripción didáctica y se evita atribuirla a la documentación.
- **NO VERIFICADO:** `ProviderNotFoundException` sí aparece (cita arriba), pero
  la afirmación «no depende del `BuildContext`» conviene matizarla: `WidgetRef`
  **sí** está ligado al árbol de widgets; lo que no está ligado es el `Ref` de
  los providers.

---

## 4. Tipos de provider y modificadores

Fuente: https://riverpod.dev/docs/concepts2/providers

- `"Providers come 6 variants:"` — **Inmutables**: `Provider`, `FutureProvider`,
  `StreamProvider`. **Mutables**: `NotifierProvider`, `AsyncNotifierProvider`,
  `StreamNotifierProvider`.
- `"There are currently two modifiers available: autoDispose... family..."`

Fuente: https://riverpod.dev/docs/3.0_migration

- `"In Riverpod 3.0, StateProvider, StateNotifierProvider, and ChangeNotifierProvider are considered "legacy". They are not removed, but are no longer part of the main API."`
- Imports exactos del código legado: `package:hooks_riverpod/legacy.dart`,
  `package:flutter_riverpod/legacy.dart`, `package:riverpod/legacy.dart`.

---

## 5. `Ref`: la API de dependencias entre providers

Fuente: https://pub.dev/documentation/riverpod/latest/riverpod/Ref-class.html

`Ref` es `sealed` y **sin parámetro de tipo**. Guía de migración:
`"Ref has lost its type parameter, and all properties/methods that were using the type parameter have been moved to Notifiers."`
y `"No more generic parameter such as Ref<T>, no more FutureProviderRef. We only have one thing: Ref."`

| Miembro | Firma | Descripción oficial (verbatim) |
|---|---|---|
| `watch` | `StateT watch<StateT>(ProviderListenable<StateT>)` | `"Obtains the state of a provider and causes the state to be re-evaluated when that provider emits a new value."` |
| `read` | `StateT read<StateT>(ProviderListenable<StateT>)` | `"Read the state associated with a provider, without listening to that provider."` |
| `listen` | `ProviderSubscription<StateT> listen<StateT>(ProviderListenable<StateT>, void Function(StateT? previous, StateT next), {void Function(Object, StackTrace)? onError, bool weak = false, bool fireImmediately = false})` | `"Listen to a provider and call listener whenever its value changes."` |
| `invalidate` | `void invalidate(ProviderOrFamily, {bool asReload = false})` | `"Invalidates the state of the provider, destroying the state immediately and causing the provider to rebuild at some point in the future."` |
| `invalidateSelf` | `void invalidateSelf({bool asReload = false})` | `"Invokes invalidate on itself."` |
| `onDispose` | `RemoveListener onDispose(void Function() listener)` | `"Adds a listener to perform an operation right before the provider is destroyed."` |
| `keepAlive` | `KeepAliveLink keepAlive()` | `"Requests for the state of a provider to not be disposed when all the listeners of the provider are removed."` |
| `mounted` | `bool get mounted` | `"Whether this Ref is still active."` · `"All methods on a provider stop being usable once this becomes false."` |

**Corrección importante:** `ref.state` y `ref.listenSelf` **ya no existen en
`Ref`** (la página `Ref/listenSelf.html` devuelve HTTP 404). La guía de
migración lo dice literalmente:
`"ProviderRef.state, Ref.listenSelf and FutureProviderRef.future should be replaced by Notifier.state, Notifier.listenSelf and AsyncNotifier.future respectively."`

---

## 6. `ConsumerWidget`, `ConsumerStatefulWidget`, `WidgetRef`

Fuente: https://riverpod.dev/docs/concepts2/consumers

- Firma exacta: `Widget build(BuildContext context, WidgetRef ref)`.
- `Consumer` recibe `builder: (BuildContext context, WidgetRef ref, Widget? child)`.
- `ConsumerState` **tiene** una propiedad `ref`: `class _MyWidgetState extends ConsumerState<MyWidget>`.
- `"we recommend using ConsumerWidget (or ConsumerStatefulWidget when you need a State)."`
- `"Do not modify any state or start any http request inside build."`

Fuente: https://riverpod.dev/docs/concepts2/refs

- watch: `"Ref.watch - This is a \"declarative\" way of listening to providers... should be your go to choice."`
- read: se usa para `"interact with a provider's state inside button clicks"`.
- `"Do not use Ref.read as a mean to \"optimize\" your code by avoiding Ref.watch."`
- `"It is safe to use WidgetRef.listen inside the build method of a widget."`

**Aviso de verificabilidad:** las reglas «DON'T use `ref.read` inside build» y
«DON'T use `ref.watch` in callbacks» **no aparecen con ese enunciado** en la
página oficial DO/DON'T. Lo que sí está es la guía de `concepts2/refs` citada
arriba. En el material del curso se cita la fuente correcta.

---

## 7. `autoDispose`, `keepAlive` y `family`

Fuente: https://riverpod.dev/docs/concepts2/auto_dispose

- `"When using code generation, providers are autoDispose by default... Initially with the non-code generation variant, autoDispose was off by default to accommodate users migrating from package:provider."`
- `"If you want to disable autoDispose, you can do so by passing keepAlive: true to the annotation."`
- Mecánica: `"When that counter reaches zero... Riverpod waits for one frame (cf. await null). If, after that frame, the provider is still not used, then the provider is destroyed and Ref.onDispose will be triggered."`
- `"If the provider is recomputed, automatic disposal will be re-enabled."` y `"you can decide when the state stops being automatically disposed."`
- Sin generación de código: `bool isAutoDispose = false` es el valor por defecto de `Provider(...)` (verificado en el código fuente de `riverpod 3.4.3`, `lib/src/providers/provider.dart`).

Fuente: https://riverpod.dev/docs/concepts2/family

- `"it allows a provider to be associated with multiple independent states, based on a unique parameter combination."`
- `"If normal providers can be assimilated to a variable, then \"family\" providers can be assimilated to a Map."`
- `"Although not strictly required, it is highly advised to enable [Automatic disposal] when using families. This avoids memory leaks..."`
- Con generación de código: `@riverpod Future<User> user(Ref ref, String id) async {...}` y
  `class UserNotifier extends _$UserNotifier { @override Future<User> build(String id) async {...} }`.
- `"Parameters passed need to have a consistent ==/hashCode."`

---

## 8. Generación de código con `@riverpod` (temática 2.3.2)

Fuente: https://riverpod.dev/docs/concepts/about_code_generation

- `"Providers can be defined either as an annotated function or as an annotated class."`
- `"Functional providers are syntax sugar for writing a Class-based provider with nothing but a build method, and as such cannot be modified by the UI."`
- `"When a function is marked as async, the provider automatically handles errors/loading states and exposes an AsyncValue."`
- Es obligatorio `part 'archivo.g.dart';` (aparece en el ejemplo oficial `main.dart`).
- El archivo generado empieza con `"// GENERATED CODE - DO NOT MODIFY BY HAND"`,
  contiene `"part of 'main.dart';"` y declara, por ejemplo,
  `@ProviderFor(helloWorld) final helloWorldProvider = HelloWorldProvider._();`
- Nomenclatura: el patrón verificado en la documentación es **`<nombre>Provider`**
  (`helloWorld` → `helloWorldProvider`). En este proyecto:
  `Tema` → `temaProvider`, `Captura` → `capturaProvider`,
  `SesionCtrl` → `sesionCtrlProvider`.
- Ejecución: `dart run build_runner watch -d`.
- La anotación admite `@Riverpod(keepAlive: bool, dependencies: [...], retry: ..., name: ...)`
  (verificado en el código fuente de `riverpod_annotation 4.0.7`,
  `lib/src/riverpod_annotation.dart`).

**Discrepancia detectada y documentada** (honestidad intelectual): el dartdoc de
la anotación dice que el `retry` por defecto `"has unlimited retries"`, pero el
código de `riverpod 3.4.3` (`ProviderContainer.defaultRetry`) tiene
`maxRetries = 10`, `minDelay = 200 ms` y `maxDelay = 6400 ms`, y la página
https://riverpod.dev/docs/concepts2/retry dice
`"By default, a provider can be retried up to 10 times, with an exponential backoff going from 200ms to 6.4 seconds."`
Se cita la **página y el código** (coincidentes) y se señala el comentario del
dartdoc como desactualizado.

---

## 9. `Notifier`, `AsyncNotifier` y `AsyncValue`

Fuentes: https://pub.dev/documentation/riverpod/latest/riverpod/Notifier-class.html ·
https://pub.dev/documentation/riverpod/latest/riverpod/AsyncNotifier-class.html ·
https://pub.dev/documentation/riverpod/latest/riverpod/AsyncValue-class.html

| Miembro | Firma | Descripción oficial |
|---|---|---|
| `Notifier.build` | `ValueT build()` | `"Initialize a Notifier."` |
| `Notifier.state` | `ValueT get/set state` | `"The value currently exposed by this notifier."` |
| `Notifier.ref` | `Ref get ref` | Acceso a las dependencias desde el notifier |
| `Notifier.listenSelf` | `RemoveListener listenSelf(void Function(ValueT? previous, ValueT next), {void Function(Object, StackTrace)? onError})` | `"Listens to changes on the value exposed by this provider."` |
| `AsyncNotifier.build` | `FutureOr<StateT> build()` | Inicialización asíncrona |
| `AsyncNotifier.state` | `AsyncValue<StateT>` | Estado con carga / error / dato |
| `AsyncNotifier.future` | `Future<StateT>` | `"resolves with the first state value that is not AsyncLoading"` |

`AsyncValue` es `sealed`: `"you are guaranteed that you cannot forget to handle
the loading/error state"`. Renombrado verificado en 3.0:
`"valueOrNull has been renamed to value."` y `"AsyncValue is now sealed"`.
El README oficial usa *pattern matching*: `AsyncData(:final value)` /
`AsyncError(:final error)`.

### 9.1. Migración oficial de `StateNotifier` a `Notifier`

Fuente: https://riverpod.dev/docs/migration/from_state_notifier

```dart
// Antes
class CounterNotifier extends StateNotifier<int> {
  CounterNotifier() : super(0);
  void increment() => state++;
  void decrement() => state--;
}
final counterNotifierProvider =
    StateNotifierProvider<CounterNotifier, int>((ref) { return CounterNotifier(); });

// Después
class CounterNotifier extends Notifier<int> {
  @override
  int build() => 0;
  void increment() => state++;
  void decrement() => state++;
}
final counterNotifierProvider = NotifierProvider<CounterNotifier, int>(CounterNotifier.new);
```

Ciclo de vida (verbatim): `"(Async)Notifiers don't have this property, since they don't get disposed of on rebuild; only their internal state is."`
y `"This happens because (Async)Notifiers lacks a mounted property, which was available on StateNotifier."`
(el sustituto en 3.0 es `ref.mounted`).

**Nota:** se detectó además una errata en el ejemplo oficial (`decrement()` del
«después» hace `state++`). No se reproduce la errata en el material del curso.

---

## 10. DO/DON'T oficiales (exactamente cinco reglas)

Fuente: https://riverpod.dev/docs/root/do_dont

1. `"AVOID initializing providers in a widget"` — `"Providers should initialize themselves. They should not be initialized by an external element such as a widget."`
2. `"AVOID using providers for Ephemeral state."` — `"Providers are designed to be for shared business state. They are not meant to be used for Ephemeral state"`; nombra como efímero `"The currently selected item."`, `"Form state"`, `"Animations."` y todo lo que Flutter resuelve con un *controller* (p. ej. `TextEditingController`).
3. `"DON'T perform side effects during the initialization of a provider"` — `"You should not use them for \"write\" operations, such as submitting a form."`
4. `"PREFER ref.watch/read/listen (and similar APIs) with statically known providers"` — `"for lints to be effective, your code should be written in a way that is statically analysable."`
5. `"AVOID dynamically creating providers"` — `"Providers should exclusively be top-level final variables."`

FAQ (https://riverpod.dev/docs/root/faq):

- `"No, there is no way to reset all providers at once. This is on purpose, as it is considered an anti-pattern."`
- `"Riverpod voluntarily dissociates Ref and WidgetRef."`
- `"Using \"ref\" when a widget is about to or has been unmounted is unsafe."`

Otras reglas verificadas en la documentación de la API:

- `"It is generally discouraged to mock Notifiers."` (https://riverpod.dev/docs/how_to/testing)
- `"The callback of ref.onDispose must not trigger side-effects."` (API de `Ref`)

---

## 11. Novedades de Riverpod 3.0 (con cita textual)

Fuente: https://riverpod.dev/docs/whats_new y https://riverpod.dev/docs/3.0_migration

| Novedad | Cita textual |
|---|---|
| Reintento automático | `"Starting 3.0, providers that fail during initialization will automatically retry. The retry is done with an exponential backoff, and the provider will be retried until it succeeds or is disposed."` · `"The default behavior retries any error, and starts with a 200ms delay that doubles after each retry up to 6.4 seconds."` |
| Providers fuera de vista en pausa | `"Riverpod relies on TickerMode to determine if a widget is visible or not. And when false, all listeners of a Consumer are paused."` · `"If a provider is only used by paused providers, it is paused too."` |
| `UnmountedRefException` | `"In Riverpod 3.0, using a Ref after its provider has been disposed throws an UnmountedRefException."` |
| `legacy.dart` | `"In Riverpod 3.0, StateProvider, StateNotifierProvider, and ChangeNotifierProvider are considered "legacy"."` |
| Filtrado con `==` | `"Starting 3.0, all providers use == to filter notifications."` |
| `ProviderObserverContext` | `"Instead of two separate parameters for ProviderContainer and ProviderBase, a single ProviderObserverContext object is passed."` |
| `Ref` unificado | `"In 3.0, Ref is unified. No more generic parameter such as Ref<T>, no more FutureProviderRef. We only have one thing: Ref."` · `"This does not concern WidgetRef, which is intact."` |
| `Ref.mounted` | `"The long-awaited Ref.mounted is finally here! It is similar to BuildContext.mounted, but for Ref."` |
| Fusiones de API | `"AutoDispose interfaces are removed"` · `"FamilyNotifier" and "Notifier" are fused` |
| `ProviderException` | `"Instead, the error will be encapsulated in a ProviderException that contains both the original error and its stack trace"`; `"AsyncValue.error, ref.listen(..., onError: ...) and ProviderObservers are unaffected by this change"` |

Firmas de `ProviderObserver` **verificadas en el código fuente de
`riverpod 3.4.3`** (`lib/src/core/provider_container.dart`, línea 1408 y
siguientes) y **no** copiadas de un blog:

```dart
abstract base class ProviderObserver {
  void didCreateProviderContainer(ProviderContainer container) {}
  void didDisposeProviderContainer(ProviderContainer container) {}
  void didAddProvider(ProviderObserverContext context, Object? value) {}
  void providerDidFail(ProviderObserverContext context, Object error, StackTrace stackTrace) {}
  void didUnmountProvider(ProviderObserverContext context) {}
  void didUpdateProvider(ProviderObserverContext context, Object? previousValue, Object? newValue) {}
  void didDisposeProvider(ProviderObserverContext context) {}
  // ... mutationStart / mutationSuccess / mutationError / mutationReset
}
```

`ProviderObserverContext` expone `container`, `provider` y `mutation`.

---

## 12. Mutations y persistencia offline (experimentales)

Fuentes: https://riverpod.dev/docs/concepts2/mutations ·
https://riverpod.dev/docs/concepts2/offline

- Mutations: `"Mutations are experimental, and the API may change in a breaking way without a major version bump."` · `"Mutations, in Riverpod, are objects which enable the user interface to react to state changes. A common use-case is displaying a loading indicator while a form is being submitted"` · estados `MutationPending`, `MutationError`, `MutationSuccess`, `MutationIdle`.
- Offline persistence: `"Offline persistence is the ability to store the state of Providers on the user's device, so that it can be accessed even when the user is offline or when the app is restarted."` · `"Currently, only "Notifiers" can be persisted."` · `"By default, state is only cached for 2 days."` · import `'package:flutter_riverpod/experimental/persist.dart'` · requiere `riverpod_sqflite` + `sqflite`.
- **NO VERIFICADO:** el identificador `ExperimentalPersistStorage` no aparece en la documentación consultada; el tipo documentado es `Storage` / `JsonSqFliteStorage`. **NO VERIFICADO:** que `@Riverpod(keepAlive: true)` sea requisito de la persistencia.

**Consecuencia didáctica:** ninguna de las dos se usa en el proyecto. Se
mencionan en la teoría como *estado del arte* y se marcan como experimentales.

---

## 13. Pruebas: `ProviderContainer`, *overrides* y `ProviderContainer.test`

Fuentes: https://riverpod.dev/docs/how_to/testing ·
https://riverpod.dev/docs/concepts2/overrides

- `"A core part of the Riverpod API is the ability to test your providers in isolation."`
- `"The main difference with any other test is that we will want to create a ProviderContainer object."`
- `"All providers can be mocked by default, without any additional setup."`
- `"Be careful when using container.read when providers are automatically disposed. If your provider is not listened to, chances are that its state will get destroyed in the middle of your test."` — de ahí que las pruebas usen `container.listen(...)` cuando el provider es *auto-dispose*.
- `"Inside tests, do not use ProviderContainer directly. Use ProviderContainer.test instead. This will automatically dispose the container when the test ends."`
- `"In Riverpod, all providers can be overridden to change their behavior."` ·
  `"Overriding a provider is done on ProviderContainers/ProviderScopes, using the overrides parameter."` ·
  `"all of them have their name starting with overrideWith"` (`overrideWith`, `overrideWithValue`, `overrideWithBuild`).
- **NO VERIFICADO:** `addTearDown(container.dispose)` **no aparece** en la documentación actual de pruebas; el reemplazo oficial es `ProviderContainer.test()`.

Verificación local adicional: `ProviderContainer.test()` está implementado como
`test.addTearDown(container.dispose)` en el código fuente
(`riverpod 3.4.3`, `lib/src/core/provider_container.dart`, línea 963), así que
funciona también dentro de `testWidgets` de `flutter_test`. Comprobado en el
proyecto: las pruebas que lo usan pasan.

---

## 14. Resumen de lo NO verificado (para no citarlo)

1. **Comparación oficial con `setState`:** no existe en la documentación de Riverpod.
2. **«Compile-safe» / «compilación segura»:** expresión no encontrada en la documentación.
3. **«No depende del `BuildContext`»:** matizable; `WidgetRef` sí depende del árbol.
4. **Reglas «no `ref.read` en `build`» y «no `ref.watch` en callbacks»:** no figuran con ese enunciado en DO/DON'T; sí está la guía de `concepts2/refs`.
5. **`ExperimentalPersistStorage`:** identificador no hallado.
6. **Tiempos concretos de la persistencia offline más allá de «2 días» por defecto:** no verificados.
7. **`contadorProvider` como nombre generado:** solo está verificado el patrón `<nombre>Provider` (`helloWorldProvider`).
8. **Comparación con BLoC:** la documentación oficial de Riverpod **no menciona BLoC** en ninguna de las páginas consultadas. La mención comparativa del sílabo («mención comparativa de BLoC como alternativa empresarial») se trata en la Semana 13 y deberá apoyarse en https://bloclibrary.dev/, no en riverpod.dev.

---

## Referencias en APA 7 (listas para copiar al informe)

- Rousselet, R. (2026). *flutter_riverpod* (Versión 3.4.3) [Paquete de Flutter]. pub.dev. https://pub.dev/packages/flutter_riverpod
- Rousselet, R. (2026). *riverpod_generator* (Versión 4.0.9) [Paquete de Dart]. pub.dev. https://pub.dev/packages/riverpod_generator
- Rousselet, R. (2026). *Riverpod documentation*. https://riverpod.dev/
- Rousselet, R. (2025). *What's new in Riverpod 3.0*. Riverpod. https://riverpod.dev/docs/whats_new
- Rousselet, R. (2025). *Migrating from 2.0 to 3.0*. Riverpod. https://riverpod.dev/docs/3.0_migration
- Rousselet, R. (2026). *About code generation*. Riverpod. https://riverpod.dev/docs/concepts/about_code_generation
- Rousselet, R. (2026). *Testing your providers*. Riverpod. https://riverpod.dev/docs/how_to/testing
- Rousselet, R. (2026). *DO/DON'T*. Riverpod. https://riverpod.dev/docs/root/do_dont
- Rousselet, R. (2026). *Ref class*. En *riverpod 3.4.3 API reference*. pub.dev. https://pub.dev/documentation/riverpod/latest/riverpod/Ref-class.html
- Rousselet, R. (2026). *Notifier class*. En *riverpod 3.4.3 API reference*. pub.dev. https://pub.dev/documentation/riverpod/latest/riverpod/Notifier-class.html
- Rousselet, R. (2026). *ProviderObserver class*. En *riverpod 3.4.3 API reference*. pub.dev. https://pub.dev/documentation/riverpod/latest/riverpod/ProviderObserver-class.html
- Google. (s. f.). *State management*. Flutter Docs. Recuperado el 15 de octubre de 2026, de https://docs.flutter.dev/data-and-backend/state-mgmt/intro
- Google. (s. f.). *Lists & grids* (widgets con estado y `setState`). Flutter Docs. Recuperado el 15 de octubre de 2026, de https://docs.flutter.dev/ui/layout/lists
- Martin, R. C. (2018). *Clean Architecture: A Craftsman's Guide to Software Structure*. Prentice Hall.
